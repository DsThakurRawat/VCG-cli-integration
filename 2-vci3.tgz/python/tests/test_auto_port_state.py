"""Source-shape guards only; native SKILL behavior requires isolated live tests."""
import os
from pathlib import Path
import re


RESOURCES = Path(os.environ.get("VB_TEST_DAEMON_RESOURCES",
    Path(__file__).parents[1] / "src/virtuoso_bridge/virtuoso/basic/resources"))
SOURCE = RESOURCES / "ramic_bridge.il"


def procedure(source, name):
    start = source.index("procedure(" + name + "()")
    end = source.find("\nprocedure(", start + 1)
    return source[start:end if end >= 0 else len(source)]


def test_stop_all_cannot_discover_or_signal_untracked_processes():
    source = SOURCE.read_text(encoding="utf-8")
    body = procedure(source, "RBStopAll")
    # The function ends before monitor creation, which contains other callbacks.
    body = body.split("; ============================================================================", 1)[0]
    executable = "\n".join(line.split(";", 1)[0] for line in body.splitlines())
    calls = re.findall(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\(", executable)
    assert calls == ["procedure", "RBStopAll", "RBStop"]
    assert "RBPort" not in executable
    assert "RBLastPid" not in executable
    # No clearing of the handle before stop success/exit can be reconciled.
    assert "RBIpc =" not in executable
    assert "fuser -k" not in source
    assert "pgrep" not in source



def test_monitor_describes_current_ciw_scope():
    source = SOURCE.read_text(encoding="utf-8")
    assert '"Stop this bridge (force)"' in source
    assert "Kill MY daemons" not in source


def test_runtime_port_survives_reload_and_monitor_edits_configuration():
    source = SOURCE.read_text(encoding="utf-8")
    config = source[:source.index('RBIdentityPath =')]
    assert "unless(boundp('RBPort)&&boundp('RBIpc)&&RBIpc&&RBIpc!='unbound" in re.sub(r"\s+", "", config)
    assert '?value RBConfiguredPort' in source
    assert 'RBMIntPort->value = RBConfiguredPort' in procedure(source, "RBMRefresh")



def test_monitor_uses_bounded_restart_and_checks_port():
    source = SOURCE.read_text(encoding="utf-8")
    body = procedure(source, "RBMApply")
    assert "integerp(" in body and "RBSetPort(RBConfiguredPort)" in body
    assert "RBStart()" not in body


def test_positive_port_preserves_registration_mode():
    source = SOURCE.read_text(encoding="utf-8")
    body = source.split("procedure(RBSetPort(port)", 1)[1].split("procedure(RBApplyPort", 1)[0]
    assert body.count('setShellEnvVar("RB_AUTO_PORT"') == 1
    assert 'when(port == 0 setShellEnvVar("RB_AUTO_PORT" "1"))' in body


def test_resource_override_is_visible(record_property):
    record_property("daemon_resources", str(RESOURCES.resolve()))
    assert SOURCE.is_file()


def test_ipc_begin_process_quotes_python_and_daemon_path_with_shell_single_quotes():
    source = SOURCE.read_text(encoding="utf-8")
    launch = next(
        line for line in source.splitlines()
        if "ipcBeginProcess(" in line and "RBDPath" in line
    )
    assert "RBQuoteShellArg(RBPython)" in launch
    assert "RBQuoteShellArg(RBDPath)" in launch
    assert "stdbuf -oL %s %s-u %s %L %L" in launch
