# Shared CIW Dialog Protection

The APIs below require a compatible client and running daemon. Check their
capabilities before use; an older checkout or a skill update alone does not
provide this protection. Without it, use manual coordination for a shared CIW.

Humans and Bridge can operate the same Virtuoso process. A popup in that
process cannot reliably be attributed to either party, even when it appears
immediately after a Bridge request. Never automatically press Enter, Cancel,
or close the current form just to unblock automation.

## Read-only Inspection

```bash
virtuoso-bridge inspect-dialogs --pid 12345 -p worker --json
virtuoso-bridge inspect-dialogs --pid 12345 --display :7 --ciw-window 0x100 --json
virtuoso-bridge inspect-dialogs -p worker --json   # PID from the running tunnel
```

The PID is on the configured GUI host. Without `--pid`, it is the Virtuoso PID
that the running tunnel's daemon proves in its authenticated handshake: no
SKILL is sent, so a blocked CIW still answers. Without a running tunnel, or
with the GUI and daemon on different hosts, pass `--pid`. This command uses
SSH/X11 only, sends no SKILL, and does not start/restart the Bridge. It may
deploy a small content-addressed inspection helper to the profile scratch
directory. Subsequent inspections reuse that helper within the same runner.

The report contains `status`, `target`, `dialogs`, and `diagnostics`:

- `clear` (exit 0): one verified CIW and no identified candidate blockers.
- `blocked` (exit 2): target-owned modal/candidate windows are present.
- `indeterminate` (exit 1): process, display, window ownership, or X11 access
  cannot be verified. This is not equivalent to an idle CIW.

Ownership uses X11 PID/transient/client-leader metadata, not window titles
or geometry. Titles and geometry can identify a *candidate* blocker but
cannot prove modality or user/Bridge origin. All sources remain `unknown`.
Missing metadata is conservative: an unrelated window with unverifiable
ownership can prevent a clear report. No popup action is suggested.

Inspection filters unmapped windows using read-only Xlib queries, rather than
recursively spawning a command for every toolkit widget. Mapped application
shells and referenced hidden ownership nodes remain subject to verification.
This is dialog-shell detection, not detection of every possible input grab or
reason a CIW can be busy. A `clear` report does not prove the CIW is idle.
Non-drawable InputOnly nodes are not visual dialog candidates. A root-level,
override-redirect, 1x1 window completely outside the root drawable is excluded
only when its queried properties are absent and the query succeeded. Known
application/modal windows and failed property queries are not excluded by this
rule. It does not establish foreign ownership or detect non-rendered modality.

## Opt-in Per-client Guard

For an already configured client:

```python
report = client.dialogs.enable_guard(timeout=15)
print(report.model_dump())

result = client.execute_skill("1+2", timeout=30)
if result.metadata.get("request_sent") is False:
    print(result.metadata["dialog_guard"])

# After the human resolves the popup, inspect before continuing.
report = client.dialogs.inspect()
```

Enabling uses the authenticated daemon capability handshake (no SKILL) to
bind the Virtuoso PID, then inspects its CIW. Optional `pid`, `display`, and
`ciw_window` must match. A blocked/indeterminate initial inspection enables
protection so following calls cannot bypass it. A binding/authentication
failure does not establish a new guard. Different GUI/daemon hosts are not
supported for automatic binding; explicit GUI-PID inspection remains available.
For a genuinely local GUI with no SSH runner, explicitly pass `local_gui=True`.
A loopback TCP endpoint alone is not local-GUI evidence: it can be an SSH tunnel.

Every guarded SKILL request receives a read-only preflight and fresh authenticated
PID handshake, so a tunnel redirected to another CIW is refused. Both checks run
side by side and both must pass before anything is sent. With
`protect_inflight=True`, a daemon loaded from this version replies to a quick
request with its result instead of "running", saving the receipt round trip;
an older daemon still works and is polled as before. A non-clear
report returns the existing `VirtuosoResult(status=ERROR)` shape with
`metadata.request_sent=False`, `outcome="not_started"`, and `dialog_guard`.
No SKILL is sent. Protection is per client, not a desktop lock or process-wide
reservation. It does not stop a human or another unguarded client from acting.
Shared mode also disables legacy connection retries, even when the caller
passes `retry_connect=True`, because a reset can occur after transmission.

On an in-flight failure, the guard inspects once if time remains and reports
`outcome="unknown"`. When the budget is exhausted it records indeterminate
inspection; call `dialogs.inspect()` separately for diagnosis. It never retries
the operation. A `clear` report after failure does not prove the operation did
not execute. Reconcile the run/save/SOS state before any explicit retry.

Maestro writer errors preserve guard evidence in `DialogBlockedError.result`,
`.inspection`, and `.outcome`. `run_and_wait` no longer closes current forms or
restarts a simulation when no history is acknowledged. Its diagnostic includes
the completion marker so a late completion can still be investigated.
During completion waiting, shared mode inspects out-of-band at most once every
ten seconds (each check capped at five seconds). A blocker stops only the Python
wait, not the simulation. `DialogBlockedError.result.metadata` retains the
acknowledged `history`, `session`, `phase="completion_wait"`, and marker. After
the user resolves the dialog, inspect/read that history rather than invoking
`run_and_wait` again, which would start another run.

`client.dialogs.inspect(pid=12345)` is also available without enabling a guard.
`client.dialogs.disable_guard()` removes protection without closing any window.

## Dialogs Your Own Calls Would Open

Some calls open a modal dialog that blocks the CIW. These helpers handle
known save prompts before the operation:

- `client.close_windows(lib, cell, view)` closes matching cellview windows.
  If any of their cellviews has unsaved changes, it closes nothing and names
  them (`unsaved="refuse"`, the default), saves them first
  (`unsaved="save"`), or discards them when explicitly requested
  (`unsaved="discard"`). Saving must leave each cellview unmodified before
  windows can close. Discard uses `dbPurge`: database handles become invalid
  and undo checkpoints for earlier edits, including other cellviews, are cleared.
  A window that an earlier close already
  took away (a linked Layout XL window) is skipped.
- XStream export refuses while the exported library has unsaved open
  cellviews, naming them, instead of opening "Save All". Save explicitly,
  then export.

To exit an explicitly selected CIW, choose how to handle display resources:

```python
# Only when the user has authorized closing this Virtuoso and saving its edits.
result = client.request_exit(
    unsaved="save", display_resources="save",
    display_path="/absolute/path/on/gui/host/display.drf",
)
print(result.metadata["exit_state"])
```

`request_exit` requires `display_resources="save"` with a path on the GUI host,
or explicit `display_resources="discard"`. The latter discards in-memory display
resource changes when exit completes. Cellviews default to `unsaved="refuse"`;
`save` and `discard` apply to **all** open cellviews, including non-window
handles. Discarding edits or exiting a shared CIW requires the user's intent,
not merely an agent's desire to unblock work. These options do not dismiss
an already-open dialog.

The helper queues one callback, rechecks unsaved cellviews, applies the chosen
policy, and calls ordinary `exit()` with Cadence's display-resource save prompt
temporarily suppressed (`layout` / `drmSuppressSaveDialogBox`). Native exit hooks still
run and may cancel or block exit. If exit returns, the prior setting is restored.
Saving/discarding happens before those hooks; it is not rolled back on a later
error or cancelled exit. This does not bypass other application-specific prompts.

`metadata.exit_state="requested"` acknowledges the queued callback, not process
termination or successful saving. `not_started` means the request was known not
to have been sent; otherwise a failed submission is `unknown`. Keep the original
result/receipt evidence and verify process state separately. Both `close_windows`
and `request_exit` disable connection retries; an uncertain result must be
reconciled before any new attempt. The helpers were verified on IC 23.1 with
isolated CIWs; this is not evidence for every application hook or IC version.

## Requests That Open A Popup

Preflight alone cannot protect a request that opens a dialog itself. With an
upgraded daemon, explicitly enable recoverable execution:

```python
client.dialogs.enable_guard(protect_inflight=True, timeout=15)
result = client.execute_skill("1+2", timeout=30)

handle = result.metadata.get("request_handle")
if handle and result.metadata.get("outcome") == "unknown":
    # Preserve this handle. Let the user resolve their dialog; do not resubmit.
    print(result.metadata)
    # Later, query only the original request. This works while CIW is blocked.
    original = client.requests.receipt(handle, timeout=10)
    print(original.model_dump())
```

This mode is opt-in and requires authenticated `recoverable_requests=1`
capabilities. An older daemon is refused, with no legacy SKILL fallback. The
default `protect_inflight=False` preserves preflight-only compatibility.
Changing daemon files on disk does not upgrade a running daemon. Arrange a
reload only in an explicitly selected idle CIW, never automatically in a
shared/active simulation process.

The daemon acknowledges a submission without waiting for CIW completion. One
worker owns the IPC lane until the original framed response arrives. That
worker has **no process-level SIGINT watchdog**. Other SKILL submissions,
including legacy clients, are refused while the lane is occupied; hello and
receipt queries remain available. Closing a client or ending its wait does
not cancel or interrupt the original operation. There is no automatic queue.

While a request remains pending, the client polls receipts and inspects the
selected X11 process at a low frequency (five seconds between inspections,
each inspection capped at five seconds and the remaining wait budget).
`blocked` or `indeterminate` stops the client wait and retains the handle.
`phase="awaiting_user"` and `waiting_for_user=True` mean an identified candidate
popup needs human attention; indeterminate inspection is not proof of a popup.
Its provenance is still unknown, even immediately after a Bridge submission.
No Enter/Cancel/close action is performed.

The handle contains only request ID, daemon-instance ID and Virtuoso PID,
not the token or SKILL source. It can be serialized and queried by a client
authenticated to the same daemon, including through a replacement SSH tunnel.
Reuse the existing client when possible. Ordinary `from_env`/`from_tunnel`
factories may run legacy SKILL-based identity checks; do not invoke them as
popup recovery while CIW is blocked. If reconstructing a receipt-only client,
use its existing authenticated TCP endpoint/credential without starting a
daemon or sending a SKILL probe. Never log the credential.
`request_state="completed"` preserves the original success/error response;
it is not proof of higher-level design or simulation acceptance. `running` or
`unknown` never grants permission to resubmit. A missing submission
acknowledgement is unknown too, with `request_sent=None`, not not-started.
After transmission is attempted, only an authenticated submission refusal
establishes `outcome="not_started"`. A local preflight or deadline that stops
before transmission also establishes that the request was not started.

Maestro writer errors retain the handle in `RequestRecoveryError.handle` and
the full `VirtuosoResult` in `.result`. `run_and_wait()` retains its session and
completion marker when startup is uncertain. A recovered run-history response
must be reconciled with that original marker/history, not used to start a
second simulation. Querying a receipt does not resume a multi-step workflow.

Simulation start errors also retain this context when they are
`DialogBlockedError` or ordinary transport errors. With the guard enabled,
missing dialog evidence is inspected once within the remaining budget (at most
five seconds). Existing evidence and exception types are preserved;
unguarded calls do not gain X11 inspection. Completion-poll transport failures
likewise retain the acknowledged history and marker, with guard evidence when
available. A confirmed unsent request remains `not_started`.

Ordinary start transport exceptions keep their original type and instance,
with added context in `.result.metadata`. If a third-party exception already
owns an unrelated `.result`, context is attached as `.virtuoso_result` instead.
Generic completion-poll failures still raise `MaestroCompletionUnknown`, which
remains catchable as `TimeoutError`, even when diagnostic inspection finds a
dialog. An existing `DialogBlockedError` or `RequestRecoveryError` keeps its
original exception identity and recovery handle.
Diagnostic attachment is best effort for custom exceptions that prohibit
new attributes; a failed attachment does not replace the original exception.

`MaestroJob.request_evidence["dialog_guard"]`, when present, records the
inspection captured at submission failure. It survives receipt reconciliation
as historical evidence, not a fresh claim that the CIW is still blocked.
`status()` remains an out-of-band job observation; no new blocked job state or
automatic resubmission is introduced.

X11 helper deployment stays lazy. Directory creation, upload and remote
readability are checked before a helper is used or cached. Missing cached
helpers are redeployed before execution, including both files needed by the
reviewed-close helper. Checked deployment failures in inspection and reviewed
close raise `X11HelperDeploymentError` (a `RuntimeError` subclass), with `stage`,
`local_helper`, `remote_target`, `returncode` and `stderr`. Legacy list-returning
X11 APIs keep their list of error dictionaries, adding these details under
`helper_deployment`. Raised transport exceptions keep their type and instance,
with details attached as `.helper_deployment`. Legacy helper preparation keeps
the runner's configured timeout defaults; budgeted inspection and close calls
continue to use their remaining timeout.
Checking or repairing a helper does not repeat an X11 action whose outcome is
uncertain.

Receipts are in-memory and bounded, not a durable job database. A daemon
restart, lost IPC pipe, malformed response, receipt expiry or unavailable
endpoint can make the outcome unverifiable. Unknown results require manual
state reconciliation; do not restart a pending daemon just to unblock an agent.
Native X11 calls and invisible input grabs retain the inspection limits below.

Finished receipts are retained for one hour with a maximum of 4096 entries,
8 MiB per original response and 32 MiB total response data. The daemon reserves
space for a worst-case response before accepting another execution and refuses
at capacity, rather than evicting young receipts. A pending request never
expires or releases the IPC lane merely because its client stops waiting.
Malformed/partial responses or a legacy timeout poison the lane: later
execution is refused (`BusyError: IPC lane is poisoned …`) because a delayed
frame could otherwise be misattributed. The daemon then sends a resync probe
and discards everything Virtuoso writes until the probe's own reply arrives,
and the lane is usable again without reloading the bridge. The lane stays
poisoned while the CIW is still blocked, and permanently if the pipe closes.
`virtuoso-bridge status` shows the lane state (`busy`, `resyncing`,
`poisoned`) from the handshake, which does not use the CIW.

Replies are also attributed by tag, not only by order: the bridge tags each
request, the CIW handler echoes the tag after the status marker, and the
daemon drops every reply that is not its own. Replies were once observed one
request behind after a request blocked behind a modal dialog; on IC 23.1 the
modal dialogs tried (an application dialog box, Layout XL's LX-2063 warning,
XStream's "Save All") answer nothing until dismissed and then reply in order,
so the source of that extra reply is unknown, and tags drop a stray reply
whatever its origin. A timed-out request's temp file is kept until its own
late reply arrives (at most one hour). The handshake reports `reply_tags: 1`.
A daemon started by an older `ramic_bridge.il` relies on in-order replies;
restart the bridge from the updated setup to get tags.

Request IDs contain a millisecond creation timestamp and random suffix. New
submissions must be no more than five minutes old or thirty seconds in the
future relative to the daemon's clock. This daemon advertises signed server
time in its hello reply, which the client prefers when creating the ID; other
implementations lacking that field require synchronized client/server clocks.
The completed-receipt retention exceeds this acceptance window, so an expired
ID cannot be used as a fresh submission. Receipt queries do not require a
fresh timestamp. This is bounded in-memory replay prevention, not durable
exactly-once execution across crashes or arbitrary clock changes.

## Explicit Recovery And Compatibility

### Reviewed Informational Close (Opt-in)

For an informational dialog whose Close behavior has been independently verified,
the API provides a two-step, single-use close. This is not generic popup approval:
save/discard/overwrite, SOS, simulation start/cancel and unknown workflows remain
outside this feature. Do not decide safety from the title or pixel hash alone.

```python
# Existing authenticated client; avoid factory SKILL probes while blocked.
client.dialogs.enable_guard(pid=verified_pid)
ticket = client.dialogs.prepare_close(
    inspected_window_id, expected_title="Exact reviewed informational title",
)
# Review ticket.preview_png_b64 and the documented Close behavior, or match an
# independently reviewed exact visual whitelist. Do NOT blindly approve every
# hash returned by the API. Preview images can contain confidential text.
result = client.dialogs.close(
    ticket, authorized=True, expected_content_sha256=approved_content_hash,
)
```

`prepare_close` only reads the target and preview. `close` defaults to unauthorized
and consumes a ticket before transport. Tickets are client-local, expire after
120 seconds, cannot be modified/replayed, and are limited to 16 outstanding
previews. Rebinding to a different endpoint or CIW invalidates approval. The
signed hello must match the selected PID; the native helper binds its process
start time to reject PID reuse. Older authenticated daemons need no protocol
upgrade for this API. When advertised, daemon-instance changes also invalidate
approval; an older daemon's restart within the same CIW is not separately detected.

The remote helper rechecks the one target-owned modal, exact window/title,
process start identity, geometry, WM metadata and visible pixels. It requires
WM_DELETE_WINDOW support and sends that message to the selected window once.
There is no Enter/escape/global keyboard input, focus stealing, window destruction,
process kill, or fallback when a window does not support the protocol. A changed,
unmapped, ambiguous or unrecognized target is refused. No SKILL is used.

Being mapped/viewable is not sufficient for a reliable image. Each capture
checks the complete target rectangle against root/ancestor clipping and higher
siblings in native stacking order, including their borders. Obscured/off-screen
pixels, shaped target/ancestor windows, mixed-depth visible inferiors, absent
libXext/SHAPE support, or a visibility scan exceeding its bounds are refused.
The target must use a TrueColor visual; visible InputOutput inferiors must share
that exact visual. Visual identity and RGB masks are bound into the snapshot.
Mutable colormaps can change displayed colors without changing pixel indices,
so DirectColor and other unsupported visuals are refused rather than guessed.
The helper does not raise, focus, or uncover a window to obtain approval.
This is intentionally conservative, including shaped window-manager frames.
XGetImage can return undefined obscured or differently-deep inferior pixels;
see the [Xlib image specification](https://www.x.org/releases/current/doc/libX11/libX11/libX11.html#XGetImage).

A short X-server grab protects each visibility check and capture, and the final
native comparison and message submission. Visibility is rechecked under the final
grab; preview PNG encoding happens after the capture grab is released. No
subprocess runs while grabbed. A helper-local hard deadline prevents a hung
native call from holding the grab indefinitely. This briefly pauses the display;
it is not a desktop reservation or protection against every client-side race.

Results distinguish `not_started` (`action_sent=false`), `requested`, `closed`,
and `unknown`. A requested message is NOT proof that the window closed. A separate
native query checks the ticket's exact display, process instance and window ID.
Only confirmed destruction (BadWindow) or unmapping yields `closed`; a mapped
window, even with an unmapped ancestor, or an unavailable/malformed query stays
`requested` without resending. A general inspection reporting `clear` is not
used as closure evidence. The result's optional `inspection` field contains this
exact-window state report (`status=window_state`, `exists`, `mapped`, target/XID),
not a general dialog inventory. A closed
window is NOT proof that a design/save/run operation succeeded. Query the original
request receipt separately when using the recoverable-request feature. Unknown
transport outcomes never trigger automatic repeat; inspect and reconcile instead.

First release is an explicit reviewed-close API, not a built-in catalog of Cadence
dialogs, a persistent automatic click policy, or a CLI that transports approval
tickets between processes. Rendering differences, obscured windows, animation and
button highlighting can invalidate a visual match; refusal is intentional.

Let the user complete their dialog whenever its provenance is unknown.
An explicitly authorized window/action can use `dismiss-window --pid PID` (or
`--display DISPLAY` with the exact `target.display` from inspection); one of them is
required for this workflow, since window IDs are not unique across displays. Both
connect with the Xauthority cookie of the Virtuoso process on that display, which
`xvfb-run`/`cdsXvfb-run` sessions need; the action never moves to another display. Confirm the window still represents
the intended dialog before invoking it. Sending a key
is not proof that the underlying save or simulation succeeded.

Legacy bulk behavior is opt-in only:

```bash
virtuoso-bridge dismiss-dialog --legacy-bulk
```

Python requires `client.dismiss_dialog(allow_legacy_bulk=True)` or the same
keyword on `x11.dismiss_dialogs`. These operations can affect unrelated/user
windows and are inappropriate in a shared CIW. The client refuses bulk
dismissal while its shared guard is enabled. Existing explicitly selected
`dismiss-window`/bootstrap commands remain opt-in tools, not automatic recovery.

## Limits

- Linux/X11 process metadata, libX11, and the existing X11 utilities are required. Missing
  dependencies, permissions, or a Wayland-only GUI return indeterminate.
- Preflight is not atomic with user interaction. A new popup can appear after
  inspection and block an in-flight request.
- Native Xlib calls are count-bounded and deadline-checked before and after
  each call, but an individual synchronous call can outlive the helper's budget.
  X server I/O loss can terminate the helper. Failed/malformed inspection is
  indeterminate, not clear; invisible input grabs are not detected.
- Neither legacy nor recoverable execution signals Virtuoso: a legacy request
  that outlives its timeout keeps running, its client gets a timeout, and the
  lane resynchronizes once Virtuoso answers. Human actions, another daemon in
  the same Virtuoso process, or external tools may still interrupt the
  operation; this is not a process-wide safety guarantee.
- Existing client factory identity checks, and other clients using the same
  CIW, are not protected before this guard is enabled.
- No background polling, automatic saving, notification scheduler, or generic
  Computer Use dependency is introduced.

Xlib's distinction between drawable `InputOutput` windows and non-drawable
`InputOnly` windows is documented in the
[Xlib specification](https://www.x.org/releases/X11R7.6/doc/libX11/specs/libX11/libX11.html).
Both types can participate in input grabs; this inspection does not claim to
detect invisible grabs or infer their owning human/agent operation.
