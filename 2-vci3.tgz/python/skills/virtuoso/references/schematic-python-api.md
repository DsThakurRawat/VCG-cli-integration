# Schematic Python API

Python wrapper for Cadence Virtuoso schematic editing via SKILL.

**Package:** `virtuoso_bridge.virtuoso.schematic`

```python
from virtuoso_bridge import VirtuosoClient
client = VirtuosoClient.from_env()
# SchematicOps is accessed via client.schematic
```

## SchematicEditor (context manager)

Collects SKILL commands, executes as a batch on `__exit__`, then runs `schCheck` + `dbSave` automatically.

```python
from virtuoso_bridge.virtuoso.schematic import (
    schematic_create_inst_by_master_name as inst,
    schematic_create_pin as pin,
    schematic_create_wire_between_instance_terms as wire,
)

with client.schematic.create(lib, cell) as sch:
    sch.add(inst("analogLib", "vdc", "symbol", "V0", 0, 0, "R0"))
    sch.add(wire("V0", "PLUS", "R0", "PLUS"))
    sch.add(pin("OUT", 3.0, 0.5, "R0", direction="output"))
    sch.add_net_label_to_transistor("M0", drain_net="OUT", gate_net="IN",
        source_net="VSS", body_net="VSS")
    # schCheck + dbSave happen automatically on exit
```

### SchematicEditor methods

| Method | Description |
|--------|-------------|
| `add(skill_cmd)` | Queue any SKILL command string (from ops functions) |
| `add_net_label_to_transistor(inst, drain_net, gate_net, source_net, body_net)` | Label MOS D/G/S/B terminals with net stubs |

### Open mode is explicit

Use `client.schematic.create(lib, cell)` to create or deliberately replace a
schematic. Use `client.schematic.modify(lib, cell)` to append changes to an
existing schematic without clearing it. The legacy `edit()` method is
deprecated and now defaults to safe append mode.

Read a schematic through the same client-bound API:

```python
data = client.schematic.read(lib, cell, include_positions=False)
```

### Inspect parameter evidence

When a device has no explicit sizing properties, compare the stored instance
properties with the values returned by its instance CDF in the same read:

```python
data = client.schematic.read(lib, cell, include_param_evidence=True)
for inst in data["instances"]:
    evidence = inst["param_evidence"]
    print(inst["name"], evidence["stored"], evidence["cdf"])
```

`stored` contains the explicit instance property bag. `cdf` contains instance
CDF values, or `None` when no instance CDF was available; an available CDF with
zero parameters is `{}`. An absent property differs from a present property
whose value is `None` (SKILL `nil`). Strings and lists are decoded, `t` becomes
`True`, and other atoms remain text.

Evidence is opt-in, unfiltered, and includes empty and long values that the
compact `params` dictionary omits. `param_filters` continues to affect only
`params`. Reading evidence runs no parameter callbacks and does not evaluate
`iPar`/`pPar` expressions. A CDF value without an explicit property establishes
what the CDF returned; confirm its origin and final netlisted value separately.

### Structured check/save diagnostics

Use `check_and_save()` when automation needs the diagnostics from one explicit
cellview rather than a generic batch result or the existing contents of the
CIW:

```python
report = client.schematic.check_and_save(
    lib,
    cell,
    capture_screenshot=True,  # optional lower-fidelity evidence
    screenshot_output="output/check-save.png",
)

if not report.ok:
    for diagnostic in report.diagnostics:
        print(diagnostic.severity, diagnostic.code, diagnostic.message)
```

`report` includes the authoritative `schCheck` error/warning counts, whether
`dbSave` succeeded, structured current-run messages, raw check/save log slices,
modal-window metadata, and an optional CIW screenshot path. Status is one of
`saved`, `check_failed`, `save_failed`, `blocked`, `timeout`,
`operation_error`, or `protocol_error`.

Cadence's public `schCheck(cv)` API returns counts, not message text. On
releases that provide `hiGetLogFileName()` and `hiFlushLogFile()`, the bridge
captures only the bytes appended to `CDS.log` during the check and save; it
never classifies stale CIW history. This path is verified against IC6.1.8 and
uses long-standing public APIs also present in newer Virtuoso releases. If log
capture is unavailable or a PDK checker bypasses `CDS.log`, the counts remain
authoritative and the report says that per-message text is unavailable.
`check_log_lines`/`save_log_lines` keep the raw lines with CDS.log's stream
tag (`\o `, `\w `, `\e `); diagnostic messages drop the tag, and `\w`/`\e`
lines without a severity word count as warnings/errors.

If a modal blocks the SKILL event loop, the call reports `blocked` and lists
the modal through read-only X11 discovery. It does not dismiss the dialog.
Because `client.screenshot()` also uses the blocked SKILL channel, screenshot
capture is deliberately skipped in this state; use the modal title/window id
for recovery. No OCR output is treated as an authoritative diagnostic.

## Deterministic constraint planning

Use the optional Python-side planner when placement conventions should be
repeatable and conflicts must be detected before editing Virtuoso. It keeps
connectivity explicit and reuses the existing `SchematicEditor`; it does not
synthesize topology or route wires.

```python
from virtuoso_bridge.virtuoso.schematic import (
    DeviceKind,
    DifferentialPairConstraint,
    GridPositionConstraint,
    SchematicInstanceSpec,
    SchematicPinSpec,
    SchematicPlanRequest,
)

request = SchematicPlanRequest(
    instances=[
        SchematicInstanceSpec("M_TAIL", PDK, NCH, kind=DeviceKind.NMOS,
            terminals={"D": "VS", "G": "BIAS", "S": "VSS", "B": "VSS"}),
        SchematicInstanceSpec("M_INP", PDK, NCH, kind=DeviceKind.NMOS,
            terminals={"D": "VOP", "G": "VINP", "S": "VS", "B": "VSS"}),
        SchematicInstanceSpec("M_INN", PDK, NCH, kind=DeviceKind.NMOS,
            terminals={"D": "VON", "G": "VINN", "S": "VS", "B": "VSS"}),
    ],
    pins=[SchematicPinSpec("VINP", "input", row=1)],
    positions=[GridPositionConstraint("M_TAIL", col=1.5, row=0)],
    differential_pairs=[
        DifferentialPairConstraint("M_INP", "M_INN", row=1, center_col=1.5)
    ],
)

plan = client.schematic.plan(request)
client.schematic.create_from_plan(lib, cell, plan)  # includes schCheck + save
report = plan.verify_readback(
    client.schematic.read(lib, cell, include_positions=True)
)
report.require_valid()
```

Built-in rules cover the 1.5-unit grid, NMOS/PMOS rows, `R0`/`MY`
differential-pair symmetry, a dedicated pin column, and output-stage column
offsets. `GridPositionConstraint` and `DifferentialPairConstraint` accept
`strength=ConstraintStrength.HARD` or `.SOFT`:

- incompatible hard constraints raise `SchematicPlanningError` before any edit;
- relaxed soft constraints remain visible in `plan.diagnostics`;
- input ordering does not change the resulting plan.

To recreate an existing design, read positions and convert them to a request:

```python
source = client.schematic.read(src_lib, src_cell, include_positions=True)
request = SchematicPlanRequest.from_readback(source)
plan = client.schematic.plan(request)
client.schematic.create_from_plan(dst_lib, dst_cell, plan)
```

See `examples/01_virtuoso/schematic/12_plan_differential_pair.py` and
`docs/adr/0002-deterministic-schematic-planner.md` for the complete acceptance
example, conflict model, and explicit non-goals.

### Exact-coordinate manifest import

When a source editor already provides instance origins, transforms, endpoint
coordinates, bends, junctions, and repeated ports, preserve that drawing with
an explicit PDK process map:

```python
result = client.schematic.import_manifest(
    "source.json",
    "process-map.json",
    processes=["pdk180", "pdk28"],
    cells=["ota", "strongarm"],
)
pngs = client.schematic.capture_import_result(result, "output/evidence")
```

This path probes live master-pin centers before import, adapts source geometry
to target-symbol pin offsets with exact axis constraints, creates both named
connectivity and visible wires, runs `schCheck`, and verifies the result by
reading it back.  It does not infer topology, placement, or PDK names.  See
`references/schematic-manifest-import.md` and
`examples/01_virtuoso/schematic_manifest/` for the JSON contracts.

### SKILL builder functions (ops)

Use these with `sch.add(...)`:

| Function | SKILL | Description |
|----------|-------|-------------|
| `schematic_create_inst_by_master_name(lib, cell, view, name, x, y, orient)` | `dbOpenCellViewByType` + `dbCreateInst` | Place instance |
| `schematic_create_wire(points)` | `schCreateWire` | Add wire from point list |
| `schematic_create_wire_label(x, y, text, just, rot)` | `schCreateWireLabel` | Add wire label |
| `schematic_create_pin(name, x, y, orient, *, direction)` | `schCreatePin` | Add pin |
| `schematic_create_pin_at_instance_term(inst, term, pin, *, direction, orientation)` | `schCreatePin` at terminal center | Pin at terminal |
| `schematic_create_wire_between_instance_terms(from_inst, from_term, to_inst, to_term)` | `schCreateWire` between terminal centers | Wire two terminals |
| `schematic_label_instance_term(inst, term, net)` | Wire stub + label | Label terminal |
| `schematic_wire_instance_terms_labeled(from_inst, from_term, to_inst, to_term, net)` | One wire + one label | Connect facing terminals of one net |
| `schematic_create_net_stub(net, x, y, *, direction, length)` | wire + `schCreateWireLabel` | Short named electrical connection |
| `pin_anchored_label_placement(x, y, direction)` | (Python only) | Label point, justification and rotation of the default convention |
| `schematic_create_net_expression(net, expression, x, y)` | `schCreateNetExpression` | Attach inherited-connection expression |
| `schematic_set_netset_property(instance, property, net)` | `dbReplaceProp` | Set an inherited-connection override |

### Default wiring convention

Schematics drawn through the bridge follow one convention, taken from
hand-drawn cells:

1. **Facing terminals of one net get one wire and one label.** When one
   instance's terminal faces another's on the same net (a chain stage's
   output and the next stage's input), draw a single wire between them with
   `schematic_wire_instance_terms_labeled`. Do not label both terminals: the
   net name would be printed twice on a short wire.
2. **Every other terminal gets a 0.25 stub and a label at the terminal end.**
   `schematic_label_instance_term` (default `cosmetic`) and
   `schematic_create_net_stub` (default `label_anchor="start"`) place it:
   - horizontal stub: text above the wire, `lowerLeft` when the stub runs
     right and `lowerRight` when it runs left, at 0.4 × height along and
     0.7 × height across from the terminal (0.025 / 0.04375 at the usual
     0.0625 height);
   - vertical stub: text rotated `R90` on the left of the wire, `lowerLeft`
     going up and `lowerRight` going down.

   Both helpers bind the offset label to the wire they create. For custom
   dimensions, choose a stub longer than the along-wire offset.

For example, a terminal at `(0.6875, 2.25)` with a stub to the right gets its
label at `(0.7125, 2.29375)`, `lowerLeft`, `R0`; a supply pin at `(0, 3)` with
a stub up gets `(-0.04375, 3.025)`, `lowerLeft`, `R90`.

```python
from virtuoso_bridge.virtuoso.schematic.ops import (
    schematic_label_instance_term as label,
    schematic_wire_instance_terms_labeled as wire_labeled,
)

with client.schematic.modify(LIB, "sar_logic") as sch:
    # Bit 5's ENB_N drives bit 4's ENB_P: one wire, one label.
    sch.add(wire_labeled("I3", "ENB_N", "I2", "ENB_P", "ENB_N<5>"))
    # Outputs and supplies: stub + label at the terminal end.
    sch.add(label("I3", "DOP", "DOP<5>"))
    sch.add(label("I3", "VDD", "VDD"))
```

When a cell already uses another style, match it. `cosmetic="legacy"` gives
the former default (`centerCenter` label on the stub midpoint). For a
coordinate-based net stub, `label_anchor="midpoint"` also restores its
former default length of 0.5.

## Netlist import and export

`client.schematic.export_netlist()` creates a fresh Virtuoso netlist package,
downloads it to the caller host, and verifies that `input.scs` is present.
`client.schematic.import_netlist()` runs `spiceIn` and converts the imported
netlist view into a schematic. Both paths return structured result objects;
inspect their status and diagnostics instead of assuming a produced directory
or cellview is valid.

```python
exported = client.schematic.export_netlist(
    "demoLib", "tb_amp", "artifacts/tb_amp_netlist", simulator="spectre"
)

imported = client.schematic.import_netlist(
    "demoLib", "imported_amp", "artifacts/amp.scs", language="Spectre",
    overwrite=False,
)
```

The export does not use the user's ADE project directory (`~/simulation` by
default): it netlists in a new private (0700) directory under `/tmp` and
removes it after the download, so the remote `source_file` and `source_dir` of
a successful result no longer exist. On failure the directory is kept and its
path is in the error. Pass `run_dir=` (an absolute path on the Virtuoso host)
to keep the package; the result's `run_dir` names the directory used.

`cell` names the subcircuit to import (spiceIn's import sub-circuit), so it
must match a `subckt` / `.SUBCKT` name in the netlist; one call converts one
subcircuit, so import a hierarchy leaf-first. Without `dev_map_file`, a default
device map sends `resistor`/`capacitor`/`inductor` primitives to analogLib
`res`/`cap`/`ind`; a map you pass replaces it (use one for PDK devices).

With `overwrite=True` the import refuses a target schematic that is open for
editing (for example in a window), before `spiceIn` runs: Virtuoso cannot copy
over it. Close the window first; read-only opens do not block the import.

By default `spiceIn` runs in a new private (0700) directory under `/tmp`,
which is removed after a successful import, so the `spiceIn` paths in a
successful result no longer exist. On failure the directory is kept and its
path is in the error. Pass `run_dir=` to keep the files; the caller then owns
that directory.

For format and `spiceIn` limitations, see [netlist.md](netlist.md).

## Low-level SKILL builders

`schematic/ops.py` — build SKILL strings without executing. Used internally by `SchematicOps` and `SchematicEditor`.

| Function | SKILL generated |
|----------|----------------|
| `schematic_create_inst(master_expr, name, x, y, orient)` | `dbCreateInst(cv master ...)` |
| `schematic_create_inst_by_master_name(lib, cell, view, name, x, y, orient)` | `dbOpenCellViewByType` + `dbCreateInst` |
| `schematic_create_wire(points)` | `schCreateWire(cv "route" "full" ...)` |
| `schematic_create_wire_label(x, y, text, just, rot)` | `schCreateWireLabel(cv ...)` |
| `schematic_create_pin(name, x, y, orient)` | `schCreatePin(cv ...)` |
| `schematic_create_pin_at_instance_term(inst, term, pin)` | Terminal center lookup + `schCreatePin` |
| `schematic_create_wire_between_instance_terms(from_inst, from_term, to_inst, to_term)` | Terminal center lookup + `schCreateWire` |
| `schematic_label_instance_term(inst, term, net)` | Terminal center + MOS-aware stub + `schCreateWireLabel` |
| `schematic_wire_instance_terms_labeled(from_inst, from_term, to_inst, to_term, net)` | Terminal centers + `schCreateWire` + one `schCreateWireLabel` |
| `schematic_check()` | `schCheck(cv)` |

## Terminal-aware helpers

`add_wire_between_instance_terms` and `add_net_label_to_instance_term` resolve pin positions from the database — no need to guess coordinates.

`add_net_label_to_transistor` is MOS-aware: it knows drain/source go up/down (flipped for PMOS), gate goes left, body goes right. The stub direction adapts to the transistor orientation.

Terminal names are matched case-insensitively (`D` or `d`). The body is labelled on a `B`, `BULK`, `BODY` or `SUB` terminal and skipped on a symbol without one, such as a 3-terminal device whose body comes from its model. For other names pass `terminal_names={"B": "sx"}`. `schematic_label_instance_term` matches names the same way and its error lists the master's terminals.
