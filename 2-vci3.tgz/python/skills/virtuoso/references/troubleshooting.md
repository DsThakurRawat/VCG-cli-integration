# Troubleshooting — Known Gotchas & Pitfalls

When something fails unexpectedly, search this file for keywords (error message, function name, symptom) before debugging from scratch.

---

## SKILL / CIW

### `csh()` returns `t`/`nil`, not command output
Never use `csh()` or `sh()` to verify files or read command output. They only return success/failure. Use `download_file` (SSH/SCP) for all remote file operations.

### `procedurep()` returns `nil` for compiled functions
Functions like `maeCreateNetlistForCorner` are compiled into .cxt — `procedurep()` returns nil even though they work. Check the installed documentation and a supported `fboundp` probe; deliberately calling with wrong arguments is not a safe availability test.

### `printf` inside `foreach` loses output to Python
`execute_skill()` returns the **value** of the SKILL expression, not whatever `printf` wrote to the CIW. So a loop that prints per iteration leaves Python holding only the loop's return value (often the input list, which prints as opaque `dd:0x…` handles):
```scheme
foreach(lyr ddGetLibList() printf("%s\n" lyr~>name))  ; CIW shows names, Python sees the list of dd objects
```
Three idiomatic save-the-output patterns:

1. **`sprintf(nil ...)` + `strcat`** — accumulate as a string return value:
   ```scheme
   let((buf)
     buf = ""
     foreach(lyr layers
       buf = strcat(buf sprintf(nil "%s\n" lyr)))
     buf)
   ```
2. **Return a structured list** — `cons + reverse`, then parse in Python:
   ```scheme
   let((out)
     out = nil
     foreach(lyr layers
       out = cons(list(lyr lyr~>foo lyr~>bar) out))
     reverse(out))
   ```
   Combine with `client.fetch()` when iterating over DFII objects.
3. **`outfile` + `download_file`** — keep the literal `printf` style, route to a file:
   ```python
   client.execute_skill('''
   let((p)
     p = outfile("/tmp/probe.log")
     foreach(lyr layers fprintf(p "%s\n" lyr))
     close(p))
   ''')
   client.download_file("/tmp/probe.log", "logs/probe.log")
   ```

Rule of thumb: pattern 2 for structured data, pattern 3 for ad-hoc multi-line diagnostics.

### `inst~>prop` returns nil for PDK devices
MOS transistor parameters (W, L, nf, fingers, m) are stored in CDF, not in schematic instance properties. Use `cdfGetInstCDF(inst)` to read them:
```scheme
let((cdf)
  cdf = cdfGetInstCDF(inst)
  printf("W=%s L=%s nf=%s\n" cdf~>w~>value cdf~>l~>value cdf~>nf~>value))
```
`inst~>prop` only works for non-CDF properties like user-added annotations.

---

## GUI Dialog Blocking

### `simInitEnvWithArgs` triggers a GUI dialog
If the run directory already exists, the dialog "Run Directory exists but has not been used in SE. Initialize?" blocks the CIW event loop — all subsequent `execute_skill` calls hang until the user clicks OK.

**Workaround:** use a fresh (unique) directory name each time, or avoid `simInitEnvWithArgs` in automated flows.

### Maestro dialogs block the SKILL channel
GUI dialogs ("Specify history name", "No analyses enabled", etc.) block the CIW
execution channel. Legacy requests can time out and trigger a process-level
interrupt. With an upgraded daemon and explicit
`client.dialogs.enable_guard(protect_inflight=True)`, a request-triggered popup
instead stops the client wait, preserves the original request handle, and does
not interrupt Virtuoso. Read the original result using
`client.requests.receipt(handle)` after human resolution, without resubmitting.

**Detection:** `client.maestro.run_and_wait(...)` times out, or an ordinary
`execute_skill()` call times out while a modal form is visible in Virtuoso.
Do not depend on another SKILL call for initial recovery: the dialog may have
blocked the same CIW event loop that serves the bridge.

**Recovery (out of band through X11):**
```bash
virtuoso-bridge inspect-dialogs --pid PID --json
virtuoso-bridge list-windows --top-level --json
# Only with explicit authorization for this window and action:
virtuoso-bridge dismiss-window WINDOW_ID --pid PID --action escape
```

The first command inspects one process without altering any window. A modal
can come from the human sharing the CIW; do not automatically close or cancel
it. CIW screenshots and form queries can use the blocked SKILL channel, so
they are unsuitable as the first diagnostic. See
[Shared CIW Dialog Protection](shared-ciw-dialogs.md) for the opt-in guard,
structured outcomes, and how a poisoned lane resynchronizes.

### ASSEMBLER-8127: cellview already open in edit mode
`maeMakeEditable()` fails with a modal dialog when the same cellview is already open in editable mode in another session (e.g. `fnxSession21` has it open while you try from `fnxSession0`). This dialog **completely blocks** the SKILL channel — even `hiFormDone` cannot reach it.

**Never call `maeMakeEditable()` unconditionally.** It can deadlock the bridge.

**Recovery when stuck:** inspect the explicitly selected Virtuoso PID through
X11 and let the user resolve the dialog. A fallback that injects Enter into the
current focus can affect a different user's window. If inspection is unavailable
or indeterminate, stop GUI mutations and request manual resolution. See
[Shared CIW Dialog Protection](shared-ciw-dialogs.md).

**Prevention:** before calling `maeMakeEditable()`, check if another session already has the cellview open in edit mode.

---

## Window / View Management

### `hiGetCurrentWindow()` returns the wrong window after open/close churn
After `hiCloseWindow` + `open_window` sequences (or any window-shuffling), the "current" window pointer can land on an unrelated panel — symptoms are `winName=nil`, `isLayoutMode=nil`, `viewBox=nil`. All subsequent `hiZoom` / `hiRedraw` calls then silently target the wrong window and the layout canvas stays empty.

**Diagnose:**
```scheme
let((w) w = hiGetCurrentWindow()
  sprintf(nil "wid=%L cv=%L lyt=%L"
          w (when(w~>cellView w~>cellView~>cellName)) w~>isLayoutMode))
```

**Fix — look up the window by content, drive it by wid explicitly:**
```python
WID = next(w["num"] for w in client.list_windows()
           if "MY_CELL" in (w.get("name") or "") and "layout" in (w.get("name") or ""))
client.execute_skill(f'hiZoom(window({WID}) list(0:0 700:700))')
client.execute_skill(f'hiRedraw(window({WID}))')
```
`window(N)` is the SKILL way to fetch a window by its integer ID — robust to focus changes. Never rely on `hiGetCurrentWindow()` for multi-step automation.

### Edits do not appear in an open window; layout shows empty boxes
Database edits do not repaint an open window. The schematic, symbol and
layout editors (`create()`/`modify()`) redraw the windows that show their
cellview after saving; raw `execute_skill` edits need `hiRedraw(window(WID))`.

A layout window at stop level 0 (Ctrl+F) draws instances as empty boxes.
`client.open_window(...)` opens a new layout window at full depth, as Shift+F
does (`leSetStopLevelToMaxHierDepth`, 31 on IC 23.1); `show_hierarchy=False`
keeps Virtuoso's own setting. A window that is already open is not changed.

### `client.screenshot(target=...)` needs an `int`, not `str`
Targets are dispatched by Python type:
- `"ciw"` → CIW
- `"current"` → `hiGetCurrentWindow()` (see caveat above)
- `int` → window ID lookup via `windowNum`
- any other `str` → treated as a **view name** (`layout`/`schematic`/`maestro`)

`client.screenshot(target=str(wid))` ends up in the view-name branch and errors with `Window not found: <number>`. Always cast: `target=int(wid)`.

### Stale `~>cellView` handle after delete+recreate
If you `ddDeleteObj` a cell and then `dbOpenCellViewByType("w")` a new one with the same name, any pre-existing window still holds a pointer to the **old** cellview. Symptoms: layout canvas all black, `cv~>shapes` on the window's cv is empty, but `dbOpenCellViewByType(... "r")` from a fresh handle shows the correct shapes on disk.

**Fix:** close the stale window first, then re-open:
```python
for w in client.list_windows():
    nm = w.get("name") or ""
    if "MY_CELL" in nm and "layout" in nm:
        client.execute_skill(f'hiCloseWindow(window({w["num"]}))')
client.open_window(LIB, CELL, view="layout")
```
Closing drops the stale reference; the next `open_window` reads the new cellview from disk.

### `rexMatchp` errors on `nil` target abort the enclosing `let`
`hiGetWindowName(w)` returns `nil` for auxiliary panels (info dialogs, etc.). Passing `nil` to `rexMatchp` is a non-recoverable SKILL error inside a `let` — the entire block silently returns an empty string, no error surfaces in Python.

**Fix:** guard the predicate:
```scheme
foreach(w hiGetWindowList()
  let((nm) nm = hiGetWindowName(w)
    when(nm && rexMatchp("MY_CELL layout" nm) ...)))
```
Or skip SKILL string-matching entirely and filter on the Python side via `client.list_windows()` — much easier to debug.

### SKILL language traps
- `t` is a protected variable: `t = 1` or `let((t) ...)` fails. Name it `tv`.
- `list((...))` is read as a call of the inner list; write a quoted literal
  `'(...)`, or `list(...)` with plain arguments.
- `cross()` returns a waveform, and with `?multiple t` a list. `length()` of a
  waveform fails; count points with
  `drVectorLength(drGetWaveformXVec(wave))`, crossings with `length()` of the
  `?multiple t` list.
- `ccpRename` takes a symbol as argument 5, e.g. `'CCP_UPDATE_DESTLIB_ONLY`,
  not a string.

### `load error at line N` with no message
Errors raised inside a `load()`ed file reach the caller only as the line
number; the message is printed to the CIW. `client.load_il()` /
`virtuoso-bridge load` append the `*Error*` lines CDS.log gained during the
load. Multi-line `eval` requests run under `errset` in the daemon since #183;
a host still running an older checkout reports only the line, so update it and
restart the daemon. To see the message on such a host, run the code as
`errset(progn(...) t)` and read `errset.errset`. Shell quoting: pass SKILL
containing `'sym` quotes through `virtuoso-bridge eval --stdin` rather than a
single-quoted argument.

---

## Netlist / si

### Netlist files are on the remote
`maeCreateNetlistForCorner` writes to the remote filesystem. Always use `client.download_file()` to retrieve them — don't try to read them via SKILL.

### si output location
`si -batch -command nl` outputs to `<runDir>/netlist` (a single file). But if something goes wrong (e.g. GUI dialog blocked), `spectre.inp` may be nearly empty. Check file size after download.

### `createNetlist` writes into the ADE project directory
OCEAN's `simulator()` → `design()` → `createNetlist()` writes `<projectDir>/<cell>/<simulator>/<view>/netlist` (and a `psf/` beside it), where `projectDir` is the `asimenv.startup` setting, `~/simulation` by default. Left alone, every run leaves a tree there and rewrites the netlist of the user's own ADE setup for that cell. OCEAN reads `projectDir` when `simulator()` starts the session (checked on IC 6.1.8), so point it elsewhere only around that call and restore it, e.g. inside `unwindProtect`. `client.schematic.export_netlist()` does this: by default it netlists in a private `/tmp` directory and removes it after the download; pass `run_dir=` to keep the package. `simulator()` also closes any OCEAN session already open in that CIW.

### Batch tool exits before an expected artifact appears

Tools such as `strmin` and `ihdl` can fork and write failures only to their own
logs, so `system()` success is not proof that translation succeeded. Stage local
input files to the tool's working directory before invocation. On every bounded
artifact poll, also inspect the tail of that invocation's log for terminal
failure markers such as `Translation failed`, `XSTRM-273` or `OPEN_FAILED`.
Stop with the diagnostic when the tool fails rather than waiting out the entire
timeout. Use unique run directories to exclude stale artifacts.

---

## Maestro / Design Variables

### `mae*` functions undefined (`*Error* undefined function`)
Older Virtuoso versions may not have `mae*` API. Use `asi*` equivalents instead. See the "asi\* Fallback" section in `maestro-skill-api.md` for the full mapping table. Detection: `fboundp('maeRunSimulation)`.

### `maeGetSetup(?typeName "globalVar")` reports an unsupported type
`"globalVar"` is not a valid `maeGetSetup` type in IC23.1 ISR16. Do not use it as a variable-discovery API. Use `asiGetDesignVarList(asiGetCurrentSession())` to read design variables; use `maeGetVar` / `maeSetVar` for one named variable. In IC23.1, `maeGetSetup` supports the types reported by its error message, including `"tests"`, `"corners"`, `"variables"`, and `"parameters"`.

### Global vs test-level variables
`maeSetVar("f" "1G")` sets a **global** variable. To set a test-level variable:
```python
client.execute_skill('maeSetVar("f" "1G" ?typeName "test" ?typeValue \'("IB_PSS"))')
```
If a test has a local variable with the same name, it overrides the global one. To delete test-level variables, use the `axl*` API (see main skill doc).

Test-level values were seen to have no effect on corner runs in IC23.10.
Set such variables per corner (`setup_corner(..., variables=...)`) and confirm
the netlisted value.

### Corner model files drop the test's includes
A corner's `modelFiles` replaces the test's list, so a std-cell include listed
there disappears from that corner's netlist. Put includes the corners must
keep in the test's `definitionFiles` (`set_env_option(client, test,
'(("definitionFiles" ("/path/std.scs")))')`).

### Analysis options accepted but not netlisted
`maeSetAnalysis` accepts options the netlister then drops, e.g. `noisefmax`
while the tran form's transient-noise toggle is off, and the toggle could not
be set through the API. Netlist a corner with `create_netlist_for_corner` and
check it with `client.maestro.check_netlist_options(path, "tran", names)`,
which returns the missing names.
Settings that only the form writes (tran Transient Noise, the sampled
pnoise jitter event, pss `autotstab`) need
[gui-fallback.md](gui-fallback.md).

### `maeAddOutput` keeps an existing output's expression
Re-adding a name keeps its old definition. Use
`client.maestro.add_output(..., replace=True)`, which deletes it first.

### Run "done" but points failed
`run_and_wait` reports Maestro finishing, not each point. A Spectre crash
(SPECTRE-18/19) still ends as "done". Pass `check=True` to raise
`MaestroPointsFailed`, or call `client.maestro.check_points(history, lib=,
cell=)` for each `spectre.out` status.

### `read_results` empty or `KeyError`
`maeExportOutputView` can return without writing the CSV. `read_results` then
returns an empty result whose `KeyError` names the reason. Compute outputs
from the PSF (`export_waveform` or OCEAN) instead.

### History-name form on every run
A site setting `adexl.historyNamePrefix showNameHistoryForm` opens a modal
form per run. `run_simulation` switches it off for its own call since #228;
an older checkout needs the update.

### Copied point netlists break
`netlist` and `ihnl` in a point directory are relative symlinks into
`psf/<TEST>/netlist`. Copy with `client.maestro.copy_point_netlist(src, dst)`
(follows the links) or `cp -RL`.

### Must `maeSaveSetup` before `maeRunSimulation`
Skipping save causes stale state — the simulation runs with old parameters. Always save before run.

---

## Connection / Tunnel

### Socket timeout at 30s
CIW is overloaded or a dialog is blocking. Check Virtuoso GUI state before retrying.

### `OPEN_FAILED` on view access
The cellview doesn't exist or is locked by another process. Verify with `ddGetObj(lib cell view)` before opening.

### Background jobs over SSH die or fail with "Ambiguous output redirect"
A csh login shell rejects `> log 2>&1`, and a job started with `&` dies when
the SSH session closes. `runner.run_detached(command, log_path)` runs it under
`sh` with `setsid nohup` and returns its PID. By hand:
`ssh host 'sh -c "setsid nohup CMD > log 2>&1 < /dev/null &"'`.

### `.il line 16` SKILL probe failure
The RAMIC daemon setup script failed to load. Run `virtuoso-bridge status` and
paste the exact generated `load("...")` line into CIW, or use the explicit
`list-windows --top-level` + `bootstrap --window WINDOW_ID` flow.
